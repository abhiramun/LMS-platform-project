from django.shortcuts import render, redirect,get_object_or_404
from django.http import JsonResponse
from django.views.generic import View
from django.contrib import messages
from django.contrib.auth import authenticate, login,logout
from .forms import *
from .models import *
from home.models import *
from django.views.decorators.csrf import csrf_exempt




class purchase_view(View):
    def get(self,req,*args, **kwargs):
        course_id = kwargs.get("cid")
        course = coursemodel.objects.get(id=course_id)
        cart, created = CartModel.objects.get_or_create(user=req.user)
        cart_item, created = CartItem.objects.get_or_create(user=req.user, course=course, cart=cart)
        cart_item.save() 
        cart_items = CartItem.objects.filter(user=req.user)
        total_price = sum(cart_item.course.course_price for cart_item in cart_items)
        total_items_in_cart = CartItem.objects.filter(user=req.user).count()
        return render (req,"checkout.html",{'cart_items':cart_items,'total_price':total_price,"total_items":total_items_in_cart})






class checkout_view(View):
    def get(self,req,*args, **kwargs):       
        cart_items = CartItem.objects.filter(user=req.user)
        total_price = sum(cart_item.course.course_price for cart_item in cart_items)
        total_items_in_cart = CartItem.objects.filter(user=req.user).count()
        return render (req,"checkout.html",{'cart_items':cart_items,'total_price':total_price,"total_items":total_items_in_cart})
    
class ProceedToPay(View):
    def get(self, request, *args, **kwargs):
        cart_items = CartItem.objects.filter(user=request.user)
        total_price = sum(cart_item.course.course_price for cart_item in cart_items)
        return JsonResponse({
            "total_price": total_price
        })
        
        
        
class PaymentSuccessView(View):
    @csrf_exempt
    def post(self, request, *args, **kwargs):
        payment_id = request.POST.get('payment_id')
        order_id = request.POST.get('order_id')
        signature = request.POST.get('signature')
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        address = request.POST.get('address')
        pincode = request.POST.get('pincode')

    

        user = request.user
        cart_items = CartItem.objects.filter(user=user)

      
        for cart_item in cart_items:
            Enrollment.objects.create(
                user=user,
                courses=cart_item.course
            )
        
       
        cart_items.delete()

        return JsonResponse({"status": "success"})
    
    
# my course view


class mycourseview(View):
    def get(self, req, *args, **kwargs):
        enrollments = Enrollment.objects.filter(user=req.user)
        return render(req, 'mycourse.html', {'enrollments': enrollments})  



class log_view(View):
    def get(self, req, *args, **kwargs):
        login_form = userlogform()
        us = req.user
        return render(req, "log.html", {"login_form": login_form, "user": us})

    def post(self, req, *args, **kwargs):
        logform_data = userlogform(data=req.POST)
        if logform_data.is_valid():
            un = logform_data.cleaned_data.get('uname')
            ps = logform_data.cleaned_data.get('pswd')
            user = authenticate(req, username=un, password=ps)
            if user:
                login(req, user)
              
                profile, created = UserProfile.objects.get_or_create(user=user)
                
                if profile.is_tutor:
                    messages.success(req, f" {user.username} logged in successfully")
                    return redirect("addcourse")
                else:
                    messages.success(req, f" {user.username} logged in successfully")
                    return redirect("home")  
            else:
                messages.error(req, "Invalid username or password")
                return redirect("log")
        else:
            messages.error(req, "Invalid login credentials")
            return render(req, "log.html", {"login_form": logform_data})
            
    
class reg_view(View):
    def get(self,req,*args, **kwargs):
        reg_form = userregform()
        return render(req,"reg.html",{'reg_form':reg_form})
    def post(self, req,*args, **kwargs):
        reg_formdata = userregform(req.POST)
        if reg_formdata.is_valid():
            reg_formdata.save()
            messages.success(req, 'Registration successful. You can now log in.')
            return redirect('log')
        else:
            return render(req, 'reg.html', {'reg_form': reg_formdata })


def logout_view(request):
    logout(request)
    return redirect('log')  


# profile

class profileview(View):
    def get(self,req,*args, **kwargs):
        try:
            user_profile = UserProfile.objects.get(user=req.user)
            form = UserProfileForm(instance=user_profile)
        except UserProfile.DoesNotExist:
            user_profile = None
            form = UserProfileForm()
        return render(req, 'profile.html', { 'form': form })
    def post(self, req, *args, **kwargs):
        try:
            user_profile = UserProfile.objects.get(user=req.user)
        except UserProfile.DoesNotExist:
            user_profile = None
        form = UserProfileForm(req.POST, req.FILES, instance=user_profile)
        if form.is_valid():
            form.save()
            messages.success(req, "Profile updated successfully")
            return redirect("home")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(req, f"Error updating profile: {error}")
            return render(req, "profile.html", {'form': form})
        
