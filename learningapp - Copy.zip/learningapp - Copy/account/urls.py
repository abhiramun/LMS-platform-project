from django.urls import path
from .views import *

urlpatterns = [
    path("login/",log_view.as_view(), name="log"),
    path("register/",reg_view.as_view(), name="register"),
    path('logout/', logout_view, name='logout'),
    path("profile/", profileview.as_view(), name="profile"),
    path("checkout/",checkout_view.as_view(), name="checkout"),
    path("checkout/<int:cid>",purchase_view.as_view(), name="purchase"),
    path('mycourse/',mycourseview.as_view(), name="mycourse"),
    path('proceed-to-pay/', ProceedToPay.as_view(), name='proceed-to-pay'),
    path('payment-success/', PaymentSuccessView.as_view(), name='payment-success'),   
]
