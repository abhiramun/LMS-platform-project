from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate
from .models import *




class userregform(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=True, widget=forms.TextInput(attrs={'placeholder': 'First Name'}))
    email = forms.EmailField(max_length=254, required=True, widget=forms.EmailInput(attrs={'placeholder': 'Email'}))
    username = forms.CharField(max_length=30, required=True, widget=forms.TextInput(attrs={'placeholder': 'Username'}))
    password1 = forms.CharField(max_length=30, required=True, widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
    password2 = forms.CharField(max_length=30, required=True, widget=forms.PasswordInput(attrs={'placeholder': 'Confirm Password'}))
    is_tutor = forms.BooleanField(required=False, label="Register as Tutor", widget=forms.CheckboxInput())

    class Meta:
        model = User
        fields = ['first_name', 'email', 'username', 'password1', 'password2','is_tutor']
        
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("This email address is already in use.")
        return email

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("This username is already taken.")
        return username
        
class userlogform(forms.Form):
    uname = forms.CharField(max_length=100, label="Username", widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Enter your username"}))
    pswd = forms.CharField(max_length=100, label="Password", widget=forms.PasswordInput(attrs={"class": "form-control", "placeholder": "Enter your password"}))
    
    def clean(self):
        cleaned_data = super().clean()
        username = cleaned_data.get('uname')
        password = cleaned_data.get('pswd')
        
        # Check if both username and password are provided
        if username and password:
            user = authenticate(username=username, password=password)
            if user is None:
                raise forms.ValidationError("Invalid username or password")
        else:
                raise forms.ValidationError("Please provide both username and password")

        return cleaned_data
    
    
    
# user profile
class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = "__all__"
        widgets = {
            'username': forms.TextInput(attrs={'required': False}),
            'name': forms.TextInput(attrs={'required': False}),
            'email': forms.EmailInput(attrs={'required': False}),
            
        }
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("This username is already taken.")
        return username

     

 
          
        