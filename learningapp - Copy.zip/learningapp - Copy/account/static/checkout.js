


// jQuery(document).ready(function($){
//     $(".paywithRazorpay").click(function (e){
//         e.preventDefault();

//         let fname = $("[name='fname']").val();
//         let lname = $("[name='lname']").val();
//         let email = $("[name='email']").val();
//         let address = $("[name='address']").val();
//         let pincode = $("[name='pincode']").val();

//         if(fname === "" || lname === "" || email === "" || address === "" || pincode === "") {
//             swal("Oops!!!", "All fields are mandatory!", "error");
//             return false;
//         } else {
//             $.ajax({
//                 method: "GET",
//                 url: "/proceed-to-pay/",
//                 success: function (response) {
//                     var options = {
//                         "key": "rzp_test_kvBV3WLjl6h3A4",
//                         "amount": response.total_price * 100,
//                         "currency": "INR",
//                         "name": "Edurica",
//                         "description": "Craft your future with delight.",
//                         "image": "", 
//                         "handler": function (response){
//                             $.ajax({
//                                 method: "POST",
//                                 url: "/payment-success/",
//                                 data: {
//                                     payment_id: response.razorpay_payment_id,
//                                     order_id: response.razorpay_order_id,
//                                     signature: response.razorpay_signature,
//                                     fname: fname,
//                                     lname: lname,
//                                     email: email,
//                                     address: address,
//                                     pincode: pincode,
//                                     csrfmiddlewaretoken: $("input[name='csrfmiddlewaretoken']").val()
//                                 },
//                                 success: function (response) {
//                                     if (response.status === "success"){
//                                         window.location.href = "/mycourse/";
//                                     }
//                                     else {
//                                         swal("Oops!!!", "Payment failed. Please try again.", "error");
//                                     }
//                                 }
//                             });
//                         },
//                         "prefill": {
//                             "name": fname + " " + lname,
//                             "email": email,
//                         },
//                         "notes": {
//                             "address": address
//                         },
//                         "theme": {
//                             "color": "#3399cc"
//                         }
//                     };
//                     var rzp1 = new Razorpay(options);
//                     rzp1.open();
//                 }
//             });
//         }
//     });
// });



jQuery(document).ready(function($){
    $(".paywithRazorpay").click(function (e){
        e.preventDefault();

        let fname = $("[name='fname']").val();
        let lname = $("[name='lname']").val();
        let email = $("[name='email']").val();
        let address = $("[name='address']").val();
        let pincode = $("[name='pincode']").val();

        if(fname === "" || lname === "" || email === "" || address === "" || pincode === "") {
            swal("Oops!!!", "All fields are mandatory!", "error");
            return false;
        } else {
            $.ajax({
                method: "GET",
                url: "/proceed-to-pay/",
                success: function (response) {
                    console.log("Proceed to pay response:", response);
                    var options = {
                        "key": "rzp_test_kvBV3WLjl6h3A4",
                        "amount": response.total_price * 100,
                        "currency": "INR",
                        "name": "Edurica",
                        "description": "Craft your future with delight.",
                        "image": "", 
                        "handler": function (response){
                            console.log("Razorpay payment response:", response);
                            $.ajax({
                                method: "POST",
                                url: "/payment-success/",
                                data: {
                                    payment_id: response.razorpay_payment_id,
                                    order_id: response.razorpay_order_id,
                                    signature: response.razorpay_signature,
                                    fname: fname,
                                    lname: lname,
                                    email: email,
                                    address: address,
                                    pincode: pincode,
                                    csrfmiddlewaretoken: $("input[name='csrfmiddlewaretoken']").val()
                                },
                                success: function (response) {
                                    console.log("Payment success response:", response);
                                    if (response.status === "success"){
                                        window.location.href = "/mycourse/";
                                    }
                                    else {
                                        console.log("Payment failed response:", response);
                                        swal("Oops!!!", "Payment failed. Please try again.", "error");
                                    }
                                },
                                error: function (error) {
                                    console.log("Payment success AJAX error:", error);
                                    swal("Oops!!!", "An error occurred. Please try again.", "error");
                                }
                            });
                        },
                        "prefill": {
                            "name": fname + " " + lname,
                            "email": email,
                        },
                        "notes": {
                            "address": address
                        },
                        "theme": {
                            "color": "#3399cc"
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.open();
                },
                error: function (error) {
                    console.log("Proceed to pay AJAX error:", error);
                    swal("Oops!!!", "An error occurred while initiating payment. Please try again.", "error");
                }
            });
        }
    });
});
