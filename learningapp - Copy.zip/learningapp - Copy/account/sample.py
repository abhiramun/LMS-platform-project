from django.shortcuts import render,redirect
from django.views.generic import View
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from .forms import *


# Create your views here.

class logview(View):
     # for  login
    def get(self,req,*args, **kwargs):
        regform = userregform()
        logform = userlogform()
        user = req.user
        return render(req,"log.html",{"logform":logform,"regform":regform,"user":user})
    def post(self, req, *args, **kwargs):
        logform_data = userlogform(data=req.POST)
        regform_data = userregform(data=req.POST)

    # Processing login form
        if logform_data.is_valid():
            un = logform_data.cleaned_data.get('uname')
            ps = logform_data.cleaned_data.get('pswd')
            user = authenticate(req, username=un, password=ps)
            if user:
                login(req, user)
                messages.success(req, "User logged in successfully")
                return redirect("home")
            else:
                messages.error(req, "Login failed")
                return redirect("log")
        
        # Processing registration form
        elif regform_data.is_valid():
            regform_data.save()
            messages.success(req, "User registered successfully")
            return redirect("log")

        # # If neither form is valid, re-render the login page with the forms and any validation errors
        # return render(req, "log.html", {"logform": logform_data, "regform": regform_data})