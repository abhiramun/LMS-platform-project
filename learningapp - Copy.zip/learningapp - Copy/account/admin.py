from django.contrib import admin
from .models import UserProfile, Order, Enrollment, Payment

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'profile_picture')
    search_fields = ('user__username',)

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'total_amount', 'status', 'created_at', 'payment_id', 'order_id')
    search_fields = ('user__username', 'status')
    list_filter = ('status', 'created_at')

@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('user', 'courses', 'enrolled_on', 'active')
    search_fields = ('user__username', 'courses__course_name')
    list_filter = ('active', 'enrolled_on')

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('order', 'amount', 'payment_date', 'payment_method', 'transaction_id', 'status')
    search_fields = ('order__id', 'transaction_id', 'status')
    list_filter = ('status', 'payment_date')
