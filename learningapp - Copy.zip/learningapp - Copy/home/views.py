from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.generic import View
from django.views import View
from django.contrib import messages
from .models import *
from django.http import JsonResponse
from .forms import *
from django.urls import reverse_lazy


# Create your views here.

class homeview(View):
    def get(self,req,*args, **kwargs):
        course = coursemodel.objects.all()
        return render(req,"home.html",{"course":course})


class detailsview(View):
    def get(self,req,*args, **kwargs):
        course_id = kwargs.get("sid")
        course = coursemodel.objects.get( id = course_id )
        
    # related course
        related_course = coursemodel.objects.all().exclude(id=course_id)
        return render(req,"details.html",{"course":course,"related_course":related_course})
    
   
class LectureView(View):
    def get(self, request, *args, **kwargs):
        course_id = kwargs.get("sid")
        course = get_object_or_404(coursemodel, pk=course_id)
        sections = Section.objects.filter(course=course).order_by('order')
        section_contents = {section: Content.objects.filter(section=section).order_by('order') for section in sections}
        

        user_progress = UserContentProgress.objects.filter(user=request.user)
        completed_contents = [progress.content.id for progress in user_progress if progress.completed]

        return render(request, "lecture.html", {
            'course': course,
            'sections': sections,
            'section_contents': section_contents,
            'completed_contents': completed_contents
        })

    def post(self, request, *args, **kwargs):
        content_id = request.POST.get('content_id')
        content = get_object_or_404(Content, pk=content_id)
        progress, created = UserContentProgress.objects.get_or_create(user=request.user, content=content)
        progress.completed = not progress.completed
        progress.save()
        return JsonResponse({'completed': progress.completed})

@login_required
def add_to_cart(request, course_id):
    if request.user.is_authenticated:
        related_course = coursemodel.objects.all().exclude(id=course_id)
        try:
            course = coursemodel.objects.get(id=course_id)
            cart, created = CartModel.objects.get_or_create(user=request.user)

            # Check if the cart item already exists for this product and user
            cart_item, created = CartItem.objects.get_or_create(user=request.user, course=course, cart=cart)

            # Increment the quantity of the cart item
            if not created:
                cart_item.save()

            messages.success(request, f"{course.course_name} added to cart successfully")
        except coursemodel.DoesNotExist:
            messages.error(request, "The course does not exist")

        return render(request,"details.html",{"course":course,"related_course":related_course})
    else:
        course = coursemodel.objects.get(id=course_id)
        cart, created = CartModel.objects.get_or_create()
        cart_item, created = CartItem.objects.get_or_create(course=course, cart=cart)
        cart_item.save()
        messages.success(request, f"{course.course_name} added to cart successfully")
        
def remove_from_cart(request, cart_item_id):
    cart_item = get_object_or_404(CartItem, id = cart_item_id )
    cart_item.delete()
    return redirect('cart')

class CartView(View):
    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            cart_items = CartItem.objects.filter(user=request.user)
            total_price = sum(cart_item.course.course_price for cart_item in cart_items)
            return render(request, "cart.html", {'cart_items': cart_items,'total_price': total_price})
        else:
            # For non-authenticated users, display the courses added to the CartModel
            cart = CartModel.objects.get_or_create(user=None)[0]
            cart_items = CartItem.objects.filter(cart=cart)
            total_price = sum(cart_item.course.course_price for cart_item in cart_items)
            return render(request, "cart.html", {'cart_items': cart_items,'total_price': total_price})



class addcourseview(View):
    def get(self,req,*args, **kwargs):
        return render(req,"add_course.html")



class courselist(View):
    def get(self,req,*args, **kwargs):
        tutor_profile = req.user.userprofile
        courses = coursemodel.objects.filter(tutor_profile=tutor_profile)
        return render(req, 'courselist.html', {'courses': courses})

@login_required    
def delete_course(request, course_id):
    tutor_profile = request.user.userprofile
    course = get_object_or_404(coursemodel, id=course_id, tutor_profile=tutor_profile)
    
    if request.method == 'POST':
        course.delete()
        return redirect('courselist')

    return render(request, 'courselist.html', {'course': course})
        
    

# adding course views
# @login_required
# def add_course(request):
#     if request.method == 'POST':
#         course_form = CourseForm(request.POST, request.FILES)
#         if course_form.is_valid():
#             course = course_form.save()
#             messages.success(request, 'Course added successfully! Now add sections.')
#             return redirect('add_section', course_id=course.id)
#     else:
#         course_form = CourseForm()
    
#     return render(request, 'newcourse.html', {'course_form': course_form})


# @login_required
def add_course(request):
    if request.method == 'POST':
        course_form = CourseForm(request.POST, request.FILES)
        if course_form.is_valid():
            course = course_form.save(commit=False)
            course.tutor_profile = request.user.userprofile 
            course.save()
            messages.success(request, 'Course added successfully! Now add sections.')
            return redirect('add_section', course_id=course.id)
    else:
        initial_data = {'tutor_profile': request.user.userprofile}
        course_form = CourseForm(initial=initial_data)
    
    return render(request, 'newcourse.html', {'course_form': course_form})



# @login_required
# def add_section(request, course_id):
#     course = get_object_or_404(coursemodel, id=course_id)
#     if request.method == 'POST':
#         section_form = SectionForm(request.POST)
#         if section_form.is_valid():
#             section = section_form.save(commit=False)
#             section.course = course
#             section.save()
#             messages.success(request, 'Section added successfully! Now add contents.')
#             return redirect('add_content', section_id=section.id)
#     else:
#         section_form = SectionForm(initial={'course': course})
    
#     return render(request, 'add_section.html', {'section_form': section_form, 'course': course})


@login_required
def add_section(request, course_id):
    course = get_object_or_404(coursemodel, id=course_id)
    if course.tutor_profile.user != request.user:
        messages.error(request, 'You do not have permission to add sections to this course.')
        return redirect('tutor_courses')  # Redirect to a page showing the tutor's courses

    if request.method == 'POST':
        section_form = SectionForm(request.POST, tutor_profile=request.user.userprofile)
        if section_form.is_valid():
            section = section_form.save(commit=False)
            section.course = course
            section.save()
            messages.success(request, 'Section added successfully! Now add contents.')
            return redirect('add_content', section_id=section.id)
    else:
        section_form = SectionForm(initial={'course': course}, tutor_profile=request.user.userprofile)
    
    return render(request, 'add_section.html', {'section_form': section_form, 'course': course})



# @login_required
# def add_content(request, section_id):
#     section = get_object_or_404(Section, id=section_id)
#     if request.method == 'POST':
#         content_form = ContentForm(request.POST, request.FILES)
#         if content_form.is_valid():
#             content = content_form.save(commit=False)
#             content.section = section
#             content.save()
#             messages.success(request, 'Content added successfully!')
#             # return redirect('add_content', course_id=section.course.id)
#             return render(request,'add_content.html',{'content_form': content_form, 'section': section})
#     else:
#         content_form = ContentForm(initial={'section': section})
    
#     return render(request, 'add_content.html', {'content_form': content_form, 'section': section})


@login_required
def add_content(request, section_id):
    section = get_object_or_404(Section, id=section_id)
    if section.course.tutor_profile.user != request.user:
        messages.error(request, 'You do not have permission to add content to this section.')
        return redirect('tutor_courses')  # Redirect to a page showing the tutor's courses

    if request.method == 'POST':
        content_form = ContentForm(request.POST, request.FILES, tutor_profile=request.user.userprofile)
        if content_form.is_valid():
            content = content_form.save(commit=False)
            content.section = section
            content.save()
            messages.success(request, 'Content added successfully!')
            # return redirect('add_content', section_id=section.id)  # If you want to clear the form for new entry
            return render(request, 'add_content.html', {'content_form': content_form, 'section': section})
    else:
        content_form = ContentForm(initial={'section': section}, tutor_profile=request.user.userprofile)
    
    return render(request, 'add_content.html', {'content_form': content_form, 'section': section})
