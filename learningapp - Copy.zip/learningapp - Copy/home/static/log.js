$(document).ready(function() {
    $("#add-to-cart").on("click", function() {
        var course_id = $("#course-id").val();
        var course_name = $("#course-name").val();
        var course_price = $("#course-price").val();
        var course_thumb = $("#course-thumb").val();


        console.log("course:",course_name)

        $.ajax({
            url: "/details/",
            method: "POST",
            data: {
                'course_id': course_id,
                'course_name': course_name,
                'course_price': course_price,
                'course_thumb': course_thumb
            },
            dataType: "json",
            success: function(response) {
                // Handle success response
                console.log(response);
            },
            error: function(xhr, status, error) {
                // Handle error response
                console.error(xhr.responseText);
            }
        });
    });
});


// modal
