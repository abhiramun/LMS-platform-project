from django import forms
from .models import coursemodel, Section, Content

class ContentAdminForm(forms.ModelForm):
    class Meta:
        model = Content
        fields = ['section', 'content_type', 'title', 'video_url', 'video_file', 'image', 'order']

   


# course adding form

class CourseForm(forms.ModelForm):
    class Meta:
        model = coursemodel
        fields = [
            'tutor_profile', 'course_name', 'course_provider', 'course_about',
            'course_language', 'course_duration', 'course_skills', 'course_price',
            'course_thumbimg', 'status'
        ]
        
    def __init__(self, *args, **kwargs):
        super(CourseForm, self).__init__(*args, **kwargs)
        self.fields['tutor_profile'].widget.attrs['readonly'] = 'readonly'
        self.fields['tutor_profile'].widget.attrs['class'] = 'readonly-field'

# class SectionForm(forms.ModelForm):
#     class Meta:
#         model = Section
#         fields = ['course', 'title', 'order', 'completed']

class SectionForm(forms.ModelForm):
    class Meta:
        model = Section
        fields = ['course', 'title', 'order', 'completed']

    def __init__(self, *args, **kwargs):
        tutor_profile = kwargs.pop('tutor_profile', None)
        super(SectionForm, self).__init__(*args, **kwargs)
        if tutor_profile:
            self.fields['course'].queryset = coursemodel.objects.filter(tutor_profile=tutor_profile)


# class ContentForm(forms.ModelForm):
#     class Meta:
#         model = Content
#         fields = ['section', 'content_type', 'title', 'video_url', 'video_file', 'image', 'order']


class ContentForm(forms.ModelForm):
    class Meta:
        model = Content
        fields = ['section', 'content_type', 'title', 'video_url', 'video_file', 'image', 'order']

    def __init__(self, *args, **kwargs):
        tutor_profile = kwargs.pop('tutor_profile', None)
        super(ContentForm, self).__init__(*args, **kwargs)
        if tutor_profile:
            self.fields['section'].queryset = Section.objects.filter(course__tutor_profile=tutor_profile)
