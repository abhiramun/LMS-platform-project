from .forms import *
from django.contrib import admin
from .models import coursemodel, Section, Content, CartModel, CartItem


# Define the inline for Section to be used within CourseAdmin
# class SectionInline(admin.TabularInline):
#     model = Section
#     extra = 1

# Define the inline for Content to be used within SectionAdmin
# class ContentInline(admin.TabularInline):
#     model = Content
#     extra = 1

@admin.register(Content)
class ContentAdmin(admin.ModelAdmin):
    form = ContentAdminForm
    list_display = ('title', 'section', 'content_type', 'order')
    list_filter = ('section', 'content_type')
    search_fields = ('title', 'course__course_name', 'section__title')

  


# Registering the other models
@admin.register(coursemodel)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('course_name', 'course_provider', 'course_language', 'course_duration', 'course_price', 'status')
    search_fields = ('course_name', 'course_provider', 'course_language')
    list_filter = ('course_provider', 'course_language', 'status')
    # inlines = [SectionInline]

@admin.register(Section)
class SectionAdmin(admin.ModelAdmin):
    list_display = ('title', 'course', 'order', 'completed')
    list_filter = ('course',)
    # inlines = [ContentInline]

@admin.register(CartModel)
class CartModelAdmin(admin.ModelAdmin):
    list_display = ('user',)

@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ('user', 'cart', 'course', 'subtotal')
    search_fields = ('user__username', 'course__course_name')
    list_filter = ('cart',)
