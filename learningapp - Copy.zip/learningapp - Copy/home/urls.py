from django.urls import path
from .views import *
from . import views
from . import certificate_view



urlpatterns = [
    path("details/<int:sid>",detailsview.as_view(), name="details"),
    path("cart/",CartView.as_view(),name="cart"),
    path('cart/<int:course_id>/',views.add_to_cart, name="cart"),
    path('cart/remove/<int:cart_item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('course/<int:sid>/lecture/', LectureView.as_view(), name='lecture'),
    path('course/<int:course_id>/generate_certificate/', certificate_view.generate_certificate, name='generate_certificate'),
    path("addcourse/",addcourseview.as_view(), name="addcourse"),
    path('add-course/', add_course, name='newcourse'),
    path('add-section/<int:course_id>/', add_section, name='add_section'),
    path('add-content/<int:section_id>/', add_content, name='add_content'),
    path("course_list/",courselist.as_view(),name="courselist"),
    path('delete-course/<int:course_id>/', views.delete_course, name='delete_course'),
    
       
]
