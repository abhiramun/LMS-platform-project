# views.py
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from .models import coursemodel

@login_required
def generate_certificate(request, course_id):
    course = get_object_or_404(coursemodel, id=course_id)
    user = request.user

    # Create the HttpResponse object with the appropriate PDF headers.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{course.course_name}_certificate.pdf"'

    # Create the PDF object, using the response object as its "file."
    doc = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    
    # Define custom styles
    title_style = ParagraphStyle(
        name='TitleStyle',
        parent=styles['Title'],
        fontSize=32,
        alignment=1,  # Center alignment
        textColor=colors.darkblue,
        spaceAfter=20,
    )
    
    name_style = ParagraphStyle(
        name='NameStyle',
        parent=styles['Title'],
        fontSize=30,
        alignment=1,  # Center alignment
        textColor=colors.black,
        spaceAfter=20,
    )
    
    normal_centered_style = ParagraphStyle(
        name='NormalCentered',
        parent=styles['Normal'],
        fontSize=18,
        alignment=1,  # Center alignment
        textColor=colors.black,
        spaceAfter=20,
    )
    
    small_centered_style = ParagraphStyle(
        name='SmallCentered',
        parent=styles['Normal'],
        fontSize=14,
        alignment=1,  # Center alignment
        textColor=colors.black,
        spaceAfter=20,
    )
    
    # Create elements for the PDF
    elements = []
    
    # Add a border and background color
    elements.append(Spacer(1, 0.5 * inch))
    p = Paragraph("EDURICA", title_style)
    elements.append(p)
    p = Paragraph("Certificate of Completion", title_style)
    elements.append(p)
    
    # Add the user's name
    p = Paragraph("This is to certify that", normal_centered_style)
    elements.append(p)
    p = Paragraph(user.get_full_name(), name_style)
    elements.append(p)
    
    # Add course name and completion text
    p = Paragraph("has successfully completed the course:", normal_centered_style)
    elements.append(p)
    p = Paragraph(course.course_name, name_style)
    elements.append(p)
    
    # Add additional details such as date and signatures
    import datetime
    completion_date = datetime.date.today().strftime("%B %d, %Y")
    p = Paragraph(f"on {completion_date}", normal_centered_style)
    elements.append(p)

    elements.append(Spacer(1, 1 * inch))
    p = Paragraph("_________________________", small_centered_style)
    elements.append(p)
    p = Paragraph(f"Course provided by : {course.course_provider}" , small_centered_style)
    elements.append(p)
    p = Paragraph(f"Skills learned : {course.course_skills}", small_centered_style)
    elements.append(p)

    # Build the PDF
    doc.build(elements)
    
    return response
