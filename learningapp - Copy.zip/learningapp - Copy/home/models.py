        
# home/models.py
from django.db import models
from django.contrib.auth.models import User

class coursemodel(models.Model):
    tutor_profile = models.ForeignKey('account.UserProfile', on_delete=models.CASCADE, related_name='courses', null=True)
    course_name = models.CharField(max_length=100)
    course_provider = models.CharField(max_length=100)
    course_about = models.CharField(max_length=1000)
    course_language = models.CharField(max_length=100)
    course_duration = models.CharField(max_length=100)
    course_skills = models.CharField(max_length=100)
    course_price = models.IntegerField(null=True)
    course_thumbimg = models.ImageField(upload_to="course_img", null=True)
    status = models.BooleanField(default=False, help_text="0=default,1=Hidden", null=True)
    created_at = models.DateTimeField(auto_now_add=True , null=True)
    updated_at = models.DateTimeField(auto_now=True , null=True)

    def __str__(self):
        return self.course_name

class Section(models.Model):
    course = models.ForeignKey(coursemodel, related_name='sections', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    order = models.PositiveIntegerField()
    completed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.course.course_name} - {self.title}"

class Content(models.Model):
    SECTION_TYPES = [
        ('video', 'Video'),
        ('image', 'Image')
    ]

    section = models.ForeignKey(Section, related_name='contents', on_delete=models.CASCADE)
    content_type = models.CharField(max_length=10, choices=SECTION_TYPES)
    title = models.CharField(max_length=200)
    video_url = models.URLField(blank=True, null=True)
    video_file = models.FileField(upload_to='section_videos/', blank=True, null=True)
    image = models.ImageField(upload_to="section_images/", blank=True, null=True)
    order = models.PositiveIntegerField()

    def __str__(self):
        return self.title

class UserCourseProgress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    course = models.ForeignKey(coursemodel, on_delete=models.CASCADE)
    completed_sections = models.ManyToManyField(Section)
    progress = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.user.username} - {self.course.course_name}"

class UserContentProgress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.ForeignKey(Content, on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)

class CartModel(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)

    def __str__(self):
        return f"{self.user.username}'s cart"

class CartItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    cart = models.ForeignKey(CartModel, on_delete=models.CASCADE)
    course = models.ForeignKey(coursemodel, on_delete=models.CASCADE)
    subtotal = models.PositiveIntegerField(default=0)

    def update_subtotal(self):
        cart_items = CartItem.objects.filter(cart=self.cart)
        total_price = sum(cart_item.course.course_price for cart_item in cart_items)
        CartItem.objects.filter(cart=self.cart).update(subtotal=total_price)
